# V3 Racing Lab PRO 3.1 — Secure Airtable Sync + Historical Validation

This is a **deployable source project**, not a secret-bearing website bundle. It preserves the existing V3 dashboard, 30 races, 341 embedded V3 forecasts, R1–R4 dossiers, multi analysis, comparisons, weather, cinematic simulator, and the limited-preview fallback. It adds a secure read-only Netlify Function and an honest calibration audit screen.

## Evidence available today (16 October 2026)

- Airtable base **Australian Racing — V3 Analysis** (`appEBALFjxF1Uxqfj`): **1,420** saved forecast-version rows in the Forecasts table, all associated with the 17 October racing project.
- `Results & Validation` table: **0 records** at audit time. This means that historical calibration **cannot yet be established**. The software reports `NO_VERIFIED_BACKTEST`, not a fabricated success rate.
- 30 archived race boards and 341 forecast rows remain bundled as offline fallback. Their win percentages are **uncalibrated**. Fewer than 30 are fully model-complete in the saved active scenario.

## ONE-TIME DEPLOYMENT — Important

**Do NOT rely on simply dragging `index.html` or this ZIP into the old static deploy page.** Static file uploads may show the new interface but **will not necessarily deploy the serverless Functions**. Use a **Git-connected Netlify site** (recommended) or Netlify CLI deployment. The secure function is essential for live Airtable reads.

### Recommended route: Git-connected Netlify

1. Unzip `V3_Racing_Lab_PRO_V3_1_LIVE_SOURCE.zip`, make a **private** GitHub repository with its contents in the repository root (the root must include `index.html`, `netlify.toml`, `functions/`). Do not upload tokens or `.env` files.
2. In Netlify, configure your **existing** `jarvispunting` project to deploy from that repository, preserving its existing site URL, or ask an account administrator to connect it. Build settings: publish directory `.`; functions directory `functions`; build command can be left blank.
3. Create a **read-only Airtable personal access token**, with `data.records:read` limited to **Australian Racing — V3 Analysis**. Do not paste the token into ChatGPT, code, a public GitHub repo, or a browser script.
4. Netlify → Project configuration → Environment variables → add: `AIRTABLE_PAT` with your secret value, scope **Functions** (if scopes are available), for **Production**. Optional settings: `AIRTABLE_BASE_ID=appEBALFjxF1Uxqfj`; `AIRTABLE_FORECAST_VERSION=V3-H3-S3 (2026-10-15)`; `AIRTABLE_VALIDATION_VERSION=...` to pin evaluation to exactly one saved version.
5. Trigger **Build & deploy**. A function deploy must be included. Netlify environment changes require a new deployment.
6. Visit `https://jarvispunting.netlify.app/api/v1/status` (returns `CONNECTED` + race/row counts). `503 NOT_CONFIGURED` means the token was not loaded into the deployed Function; `404` means the Function or redirect wasn't deployed; `502 SYNC_FAILED` means an Airtable scope, base or API issue. Then open **Data & Sync** in the app and select *Test live connection*.

### Alternative: Netlify CLI (desktop)

From the unpacked project after logging in and linking to your existing Netlify site:

```bash
npm install -g netlify-cli
netlify login
netlify link
netlify deploy --prod
```

Do not include `AIRTABLE_PAT` in CLI command history. Store it through **Netlify project environment variables** in the website UI; deploy again after setting it. The CLI deploy builds/uploads both static assets and serverless functions.

## What the live integration does

- `GET /api/v1/status`: connectivity, chosen snapshot version, total returned rows, quality flags.
- `GET /api/v1/snapshot`: same-shape racing dataset from Airtable, with duplicate detection, scratch status, 30 board checks, and source timestamps. Uses a **5-minute server-side cache**. Frontend requests about every **15 minutes while open** and skips disruptive refreshes while using the Simulator/Multi Lab.
- `GET /api/v1/calibration`: independently checks verified race outcomes against **reviewed/frozen pre-race** forecasts, only scoreable for complete 100% starter boards. Never changes stored V3 model numbers.

**Important:** These endpoints read the configured `AIRTABLE_FORECAST_VERSION` (default V3-H3-S3), not the newest record by guesswork. Switching models must be deliberate and versioned. Reading Airtable is **not the same as scraping live official declarations** or recalculating model probabilities. If a scratched runner disappears, the backend flags the board as incomplete rather than pretending to re-estimate probabilities.

## Security caveat for a future paid product

The API holds the Airtable token privately, but **the read-only racing snapshots it returns are visible to visitors of your Netlify website**. If the saved model is proprietary, restrict site access or implement authenticated membership/authorization before public launch. The weather provider currently used by the frontend may have noncommercial licensing limitations. Source and official results licensing must be checked before offering a subscription.

## Calibration status and requirements

A real backtest requires historical **pre-race** predictions plus independent post-race results. The data in the existing Airtable base currently contains no completed verified results. To accumulate valid samples:

1. Freeze predictions **before** the race with a durable dated version/commit and never retrospectively rewrite it. The included `validation/` manifest hashes the bundled fixture but **is not external timestamp notarization**.
2. Add verified starter/winner outcomes into the existing `Results & Validation` table. Each record must have its original `Forecast ID`, official result URL, finish position, exactly matching probability, `Result verified` check, and matching `Race ID` / `Runner ID`. Exclude scratched and abandoned runners.
3. Keep one declared model version per race in the evaluation dataset. If multiple versions exist, set `AIRTABLE_VALIDATION_VERSION` to prevent cherry-picking. The validator rejects ambiguous duplicate versions.
4. Once there are eligible races, review **race-level multiclass Brier score**, **mean winner log loss**, comparison to a uniform-field baseline, per-runner Brier score, expected calibration error, and grouped reliability bins with Wilson intervals. Do not advertise calibration on tiny samples; ≥100 independent races is only an initial diagnostic threshold, not a magic guarantee.
5. Fit any post-hoc calibration mapping using **earlier** training races, then validate on later **held-out** meetings. Historical frozen flags must be independently supported by original timestamps/audit, because a later checkbox edit is not proof of a pre-race prediction.

## QA / local testing

```bash
node --test tests/test-core.cjs
python tests/browser.py
python tests/live_frontend.py
```

The browser tests run with embedded archive and stubbed server responses; they are not a live test against your Netlify site's Airtable secret. **No private tokens are included in this package**.
