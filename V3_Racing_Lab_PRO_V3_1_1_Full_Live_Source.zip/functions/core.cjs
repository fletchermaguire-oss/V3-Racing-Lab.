'use strict';
const TRACKS = ['RANDWICK','CAULFIELD','DOOMBEN'];
const FIELD = Object.freeze({
  raceId:'fldavoEzhnsuYpJrH', raceName:'fldIJ41U2Nr5HHea9', distance:'fldcLtcwsneVvIkRn',raceNo:'fldjqzf5sFZXQ93tJ',active:'fldnz6nfcfsOsj51q',scratched:'fld1p29Ot7Dd3eEWG',trackVerified:'fldWzv7oVPckmvBCq',updated:'fld73BHzK3HdCekKc',
  runnerId:'fldPDc1ebCqhi6kf4', runnerRace:'fld4BGD5iAcZcGfaN',horse:'fldll7dYIGf28MAKA',barrier:'fldDefVa4OkwkHpfO',status:'fldsSdoQPBOyW0AOJ',
  forecastId:'fldokMqkhMQ3qLo9m',forecastRace:'fldWripXwGb4yNS5k',forecastRunner:'fldlNuMRhiXPdssP4',version:'fldnXl37lDBWEKPLy',prob:'fldsy2wUuEWVq2zeZ',rating:'fldOxrRLCPmnpOGUM',created:'fldgCoHHg9JDWnogB',frozen:'fldvheap2k11VTAy0',reviewed:'fldUSHTR833Gz9e7E',
  meetingId:'fldEZnYwep5d4Lwv1', meetingSurface:'fldXYobhp1kBXs1Cd',meetingRail:'fldhvEXnVvQ3Po4FH',meetingSource:'fldttsp5LuO5Mk4kk',
  resultId:'flda5RBcBKWTuOvJC', resultRace:'fldXDeAa31u1AsBHS',resultRunner:'flde6jWjF8rjLYeCB',resultForecast:'fldtCqK4Z1HZiULnv',resultDate:'fldJlx8cYaNyOKWBL',outcome:'fldEHj6FSISmtmi2u',position:'fldrWVNYMeMYVsvMn',resultPred:'fldXFS439SckEBWrr',resultActual:'fldMIe2dwxxkL04qS',resultVerified:'fldjXtLvbHzcXkMiy',resultURL:'fldnvMqgdsYTcAz19',
});
const TABLES={races:'tblPkJMKWwgg9UnfQ',runners:'tblgd0S8yuysxmsVk',forecasts:'tbl2SQv9gGsoXCxyI',meetings:'tblKobbEVzBylwTuP',results:'tblo2rLfr9bjl583j'};
const norm=s=>String(s||'').trim();
const selectName=v=>v&&typeof v==='object'?v.name:typeof v==='string'?v:null;
const raceKey=id=>{const m=/^\d{4}-\d\d-\d\d_(RANDWICK|CAULFIELD|DOOMBEN)_R(\d\d)$/.exec(id||'');return m?m[1]+'_R'+m[2]:null};
const sum=xs=>xs.reduce((s,x)=>s+x,0);
function assemble(base,{races=[],runners=[],forecasts=[],meetings=[]},version){
  if(!base||!Array.isArray(base.races)||base.races.length!==30)throw Error('Source snapshot is missing race catalogue');
  const archive=structuredClone(base),original=new Map(archive.races.map(r=>[r.id,r]));
  const latestRaces=new Map();for(const record of races){const f=record.fields||{},id=raceKey(f['Race ID']);if(id&&original.has(id))latestRaces.set(id,f)}
  const runnerById=new Map();for(const record of runners){let f=record.fields||{},id=f['Runner ID'];if(!id)continue;if(runnerById.has(id))throw Error('Duplicate runner ID in Airtable: '+id);runnerById.set(id,f)}
  const rows=[],seen=new Set(),versionRows=forecasts.filter(x=>x.fields?.Version===version),warnings=[];
  for(const record of versionRows){const f=record.fields||{},id=f['Runner ID'],run=runnerById.get(id),race=raceKey(f['Race ID']);if(!race||!original.has(race))continue;
    if(!run){warnings.push('Forecast runner missing from Runners: '+id);continue}
    const status=selectName(run.Status);if(status==='Scratched'||status==='Emergency'||status==='Withdrawn')continue;
    if(run['Race ID']!==f['Race ID'])throw Error('Runner/forecast race mismatch: '+id);
    const name=norm(run.Horse),p=Number(f['Win probability %']),rating=Number(f['Rating / 100']);
    if(!name||!Number.isFinite(p)||p<0||p>100||!Number.isFinite(rating)||rating<0||rating>100)throw Error('Invalid forecast / runner data: '+id);
    const key=race+'|'+id;if(seen.has(key))throw Error('Duplicate forecast for '+key);seen.add(key);
    rows.push({race,name,p,rating,barrier:Number.isInteger(run.Barrier)&&run.Barrier>0?run.Barrier:null,runnerId:id,forecastId:f['Forecast ID'],status:status||'Unknown'});
  }
  if(rows.length<250)throw Error('Only '+rows.length+' valid runner forecasts: need ≥250 to update entire card');
  const issue=[];for(const race of archive.races){const match=latestRaces.get(race.id);if(match){race.n=Number(match['Active runners'])||race.n;race.fieldStatus=selectName(match['Field verification'])||'Unknown';race.fieldCheckedAt=match['Field checked at']||null;}const actual=rows.filter(h=>h.race===race.id);const s=sum(actual.map(h=>h.p));race.sum=Number(s.toFixed(2));if(Math.abs(s-100)>.16||match&&match['Active runners']!==actual.length){issue.push({race:race.id,fieldCount:actual.length,officialActive:match?.['Active runners']??null,totalProbability:race.sum,reason:'Incomplete, mismatched, or scratch-adjusted snapshot; simulation cannot be treated as a full-field draw'})}}
  for(const m of meetings){const f=m.fields||{},id=f['Meeting ID']||'',tr=TRACKS.find(x=>id.endsWith('_'+x));if(!tr||!archive.tracks[tr])continue;let c=selectName(f['Track condition']);if(c)archive.tracks[tr].surface=c;if(f['Rail position'])archive.tracks[tr].rail=f['Rail position'];archive.tracks[tr].updated='Airtable source time '+(f['Source timestamp']||'unspecified')+' · official condition may be stale';}
  archive.records=rows; archive.model=version;archive.source='Read-only live Airtable query, not live official racing feed';archive.syncedAt=new Date().toISOString();archive.syncQA={warnings,issues:issue,forecasts:rows.length,activeRaceBoards:archive.races.length};
  return archive;
}
function dateOnly(s){let match=/^(\d{4}-\d\d-\d\d)/.exec(norm(s));return match?.[1]||null}
function calcCalibration({results=[],forecasts=[],validationVersion=null}){
  const fMap=new Map();for(const row of forecasts){const f=row.fields||{};if(f['Forecast ID'])fMap.set(f['Forecast ID'],f)}
  const groups=new Map();let unverified=0;for(const row of results){const r=row.fields||{};if(r['Result verified']!==true){unverified++;continue}
    let rid=norm(r['Race ID']),fid=norm(r['Forecast ID']),fo=fMap.get(fid),date=dateOnly(r['Race date']),outcome=selectName(r.Outcome);
    if(!rid||!fid||!date||!fo)continue;
    if(validationVersion&&fo.Version!==validationVersion)continue;const key=rid+'|'+norm(fo.Version);if(!groups.has(key))groups.set(key,[]);groups.get(key).push({r,fo,actual:outcome==='Won'?1:0,outcome,date});
  }
  const approved=[],rejected=[];const uniqueVersions=new Map();for(const key of groups.keys()){const race=key.split('|')[0];if(!uniqueVersions.has(race))uniqueVersions.set(race,[]);uniqueVersions.get(race).push(key)}for(const [key,entries] of groups){let why=[];const race=key.split('|')[0],dates=new Set(entries.map(x=>x.date));if(uniqueVersions.get(race).length>1)why.push('Multiple forecast versions for one race; pin a validation version before scoring');if(dates.size!==1)why.push('Mixed result dates');if(entries.length<3)why.push('Fewer than three verified starters');let runners=new Set(),frozenDate=entries[0].date;
    for(const x of entries){if(x.fo.Frozen!==true||x.fo.Reviewed!==true)why.push('Forecast was not reviewed and frozen');if(x.fo['Race ID']!==race||x.fo['Runner ID']!==x.r['Runner ID'])why.push('Forecast/result identity mismatch');if(!dateOnly(x.fo['Created at local'])||dateOnly(x.fo['Created at local'])>=frozenDate)why.push('No provable pre-race forecast timestamp');if(x.outcome==='Scratched'||x.outcome==='Abandoned'||x.outcome==='Unknown')why.push('Non-starter or abandoned entry');if(!['Won','Placed','Unplaced'].includes(x.outcome))why.push('Outcome missing');if(!x.r['Official result URL'])why.push('Official source URL missing');if(runners.has(x.r['Runner ID']))why.push('Duplicate runner outcome');runners.add(x.r['Runner ID']);let p=x.fo['Win probability %'],copy=x.r['Predicted win %'];if(!Number.isFinite(p)||p<0||p>100||!Number.isFinite(copy)||Math.abs(p-copy)>.05)why.push('Forecast probability provenance mismatch');if(x.r['Actual win indicator']!==x.actual)why.push('Winner indicator mismatch')}
    const officialForecastCount=forecasts.filter(v=>v.fields?.['Race ID']===race&&v.fields?.Version===entries[0].fo.Version).length;
    if(officialForecastCount!==entries.length)why.push('Missing race starters/results against the pre-race forecast field');
    for(const x of entries){const pos=x.r['Finishing position'];if(!Number.isInteger(pos)||pos<1)why.push('Verified finishing position missing');else if((pos===1)!==(x.actual===1))why.push('Position and winner indicator disagree')}
    const winners=sum(entries.map(x=>x.actual)),mass=sum(entries.map(x=>Number(x.fo['Win probability %'])||0));if(winners!==1)why.push('Expected exactly one winner');if(Math.abs(mass-100)>.16)why.push('Starter probabilities do not sum to 100');
    if(why.length){rejected.push({race,version:key.split('|').slice(1).join('|'),issues:[...new Set(why)]});continue}
    approved.push({race,version:key.split('|').slice(1).join('|'),n:entries.length,winner:entries.find(x=>x.actual).r['Runner ID'],participants:entries.map(x=>({p:x.fo['Win probability %']/100,y:x.actual}))});
  }
  const observations=approved.flatMap(x=>x.participants),nRaces=approved.length,nRunner=observations.length,brier=observations.length?sum(observations.map(x=>(x.p-x.y)**2))/observations.length:null;
  const raceBrier=nRaces?sum(approved.map(x=>sum(x.participants.map(v=>(v.p-v.y)**2))))/nRaces:null;
  const baseline=nRaces?sum(approved.map(x=>1-1/x.n))/nRaces:null;
  const logLoss=nRaces?sum(approved.map(x=>-Math.log(Math.max(1e-12,x.participants.find(p=>p.y===1).p))))/nRaces:null;
  const bands=[[0,.05],[.05,.10],[.10,.20],[.20,.30],[.30,.50],[.50,1.0000001]].map(([min,max])=>{const a=observations.filter(x=>x.p>=min&&x.p<max),n=a.length,wins=sum(a.map(x=>x.y)),forecast=n?sum(a.map(x=>x.p))/n:null,actual=n?wins/n:null;return {range:`${Math.round(min*100)}–${Math.round(max*100)}%`,n,wins,forecast,actual}});
  for(const b of bands){if(!b.n){b.wilson95=null;continue}const z=1.96,n=b.n,phat=b.wins/n,den=1+z*z/n,centre=(phat+z*z/(2*n))/den,half=z*Math.sqrt((phat*(1-phat)+z*z/(4*n))/n)/den;b.wilson95=[Math.max(0,centre-half),Math.min(1,centre+half)];}
  const ece=nRunner?sum(bands.filter(x=>x.n).map(x=>x.n*Math.abs(x.forecast-x.actual)))/nRunner:null;
  const status=nRaces===0?'NO_VERIFIED_BACKTEST':nRaces<100?'PROVISIONAL_SMALL_SAMPLE':'OBSERVED_NOT_PROOF_OF_FUTURE_PERFORMANCE';
  return {status,asOf:new Date().toISOString(),eligibleRaces:nRaces,eligibleRunners:nRunner,totalResultRecords:results.length,unverifiedRecords:unverified,rejectedRaceVersions:rejected.length,details:rejected.slice(0,30),raceBrier,runnerBrier:brier,uniformBaselineRaceBrier:baseline,raceLogLoss:logLoss,ece,bands,minRecommendedRaces:100,validationVersion:validationVersion||'One unambiguous version per race',method:'Race-complete, verified outcomes and frozen pre-race snapshots only; no fitted calibration mapping or corrections',warning:nRaces===0?'No verified completed historical forecasts and matching results. Do not claim calibration or publish accuracy figures.':nRaces<100?'Small historical sample. Do not claim calibrated probabilities.':'Observed reliability is descriptive and requires independent held-out validation.'};
}
module.exports={FIELD,TABLES,assemble,calcCalibration};
