'use strict';
const BASE=require('./snapshot-base.json');
const {TABLES,assemble,calcCalibration}=require('./core.cjs');
let cache={};const AGE=5*60*1000;
const pause=ms=>new Promise(r=>setTimeout(r,ms));
function reply(code,object,cacheSeconds=0){return {statusCode:code,headers:{'content-type':'application/json; charset=utf-8','cache-control':`public, max-age=${cacheSeconds}`,'x-content-type-options':'nosniff'},body:JSON.stringify(object)}}
let lastApiCall=0;
async function throttle(){const wait=Math.max(0,260-(Date.now()-lastApiCall));if(wait)await pause(wait);lastApiCall=Date.now()}
async function list(name,query={}){
 const pat=process.env.AIRTABLE_PAT,base=process.env.AIRTABLE_BASE_ID||'appEBALFjxF1Uxqfj';if(!pat)throw new Error('Airtable server secret AIRTABLE_PAT is not configured');let offset,records=[],count=0;
 do{const url=new URL(`https://api.airtable.com/v0/${base}/${TABLES[name]}`);url.searchParams.set('pageSize','100');for(const [k,v] of Object.entries(query))url.searchParams.set(k,v);if(offset)url.searchParams.set('offset',offset);
  let response;for(let attempt=0;attempt<4;attempt++){await throttle();response=await fetch(url,{headers:{Authorization:`Bearer ${pat}`,Accept:'application/json'},signal:AbortSignal.timeout(20000)});if(response.status!==429&&response.status<500)break;await pause(Math.min(3000,350*(2**attempt)));}
  if(!response.ok){const text=await response.text();throw new Error(`Airtable ${name}: HTTP ${response.status} ${text.slice(0,140)}`)}const doc=await response.json();records.push(...(doc.records||[]));offset=doc.offset;if(++count>25)throw new Error('Airtable paging safety limit exceeded');await pause(230);
 }while(offset);return records;
}
async function cached(key,fn){if(cache[key]&&Date.now()-cache[key].at<AGE)return cache[key].data;const d=await fn();cache[key]={at:Date.now(),data:d};return d}
const version=()=>process.env.AIRTABLE_FORECAST_VERSION||'V3-H3-S3 (2026-10-15)';
async function snapshot(){return cached('snapshot:'+version(),async()=>{const races=await list('races');const runners=await list('runners');const forecasts=await list('forecasts',{filterByFormula:`{Version} = '${version().replaceAll("'","\\'")}'`});const meetings=await list('meetings');
 return assemble(BASE,{races,runners,forecasts,meetings},version());});}
async function calibration(){return cached('calibration',async()=>{const results=await list('results');if(!results.length)return calcCalibration({results:[],forecasts:[]});const forecasts=await list('forecasts');return calcCalibration({results,forecasts,validationVersion:process.env.AIRTABLE_VALIDATION_VERSION||null});});}
exports.handler=async event=>{
 if(event.httpMethod!=='GET')return reply(405,{error:'Read-only API. GET requests only.'});
 const route=(event.path||'').split('/').filter(Boolean).at(-1);
 if(!process.env.AIRTABLE_PAT)return reply(503,{status:'NOT_CONFIGURED',message:'Set AIRTABLE_PAT as a private Netlify environment variable. The ChatGPT connector does not configure the published website.'});
 try{if(route==='snapshot')return reply(200,await snapshot(),60);if(route==='calibration')return reply(200,await calibration(),60);if(route==='status'){const s=await snapshot();return reply(200,{status:'CONNECTED',asOf:s.syncedAt,modelVersion:s.model,races:s.races.length,forecasts:s.records.length,issues:s.syncQA?.issues?.length,officialResults:'not live - sourced from saved Airtable data'},60)}return reply(404,{error:'Unknown API endpoint'});
 }catch(e){console.error('Live racing API',e.message);return reply(502,{status:'SYNC_FAILED',message:e.message.replace(/Bearer\s+\S+/g,'Bearer [REDACTED]')});}
};
