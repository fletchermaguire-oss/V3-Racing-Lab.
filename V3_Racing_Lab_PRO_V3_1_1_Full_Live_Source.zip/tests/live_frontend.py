from playwright.sync_api import sync_playwright
from pathlib import Path
html=Path('/mnt/data/v3_live_build/index.html').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':390,'height':844});errors=[];page.on('pageerror',lambda x:errors.append(str(x)));page.set_content(html);page.wait_for_timeout(100)
 page.evaluate('''() => {const snap=JSON.parse(document.querySelector('#payload').textContent);snap.syncedAt=new Date().toISOString();snap.model='V3-H3-S3 (2026-10-15)';snap.syncQA={issues:[],forecasts:341};window.fetch=async (u)=> {const body = u.includes('calibration') ? {status:'NO_VERIFIED_BACKTEST',eligibleRaces:0,eligibleRunners:0,totalResultRecords:0,unverifiedRecords:0,rejectedRaceVersions:0,raceBrier:null,raceLogLoss:null,warning:'No verified historical races',bands:[]} : snap;return {ok:true,json:async()=>body}};}''')
 page.evaluate("document.querySelector('[data-page=\"settings\"]').click()")
 page.locator('[data-action="sync-backend"]').first.click();page.wait_for_timeout(150)
 assert 'Airtable snapshot connected' in page.locator('#screen').inner_text(),page.locator('#screen').inner_text()[:700]
 assert 'Airtable synced' in page.locator('#airtableStatusPill').inner_text()
 page.evaluate("document.querySelector('[data-page=\"calibration\"]').click()")
 page.locator('[data-action="sync-calibration"]').first.click();page.wait_for_timeout(100)
 assert 'NO_VERIFIED_BACKTEST' in page.locator('#screen').inner_text()
 assert not errors,errors
 print('Frontend live API mock: CONNECTED, 341 rows, calibration no-data and navigation checked')
 b.close()
