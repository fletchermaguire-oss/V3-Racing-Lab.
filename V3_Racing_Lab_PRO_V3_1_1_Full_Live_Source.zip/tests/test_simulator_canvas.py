"""Regression: ensure cinematic simulator horses remain visible, including after canvas DOM replacement."""
from pathlib import Path
from playwright.sync_api import sync_playwright

HTML=Path(__file__).resolve().parents[1].joinpath('index.html').read_text()
CAMERAS=['broadcast','aerial','finish','telemetry']
with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
  for width,height in [(390,844),(1365,900)]:
    page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=2)
    errors=[]
    page.on('pageerror', lambda err: errors.append(str(err)))
    page.set_content(HTML,wait_until='load')
    page.locator('[data-page="simulator"]:visible').first.click()
    page.wait_for_timeout(170)
    def canvas_state():
      return page.evaluate('''() => {let e=document.querySelector('#s3Canvas'); let c=e.getContext('2d');
       let w=e.width,h=e.height,rect=e.getBoundingClientRect(),pix=c.getImageData(0,0,w,h).data;
       let coloured=0, solid=0, green=0;
       for(let i=0;i<pix.length;i+=4){
        if(pix[i+3]===255)solid++;
        if(pix[i]>130 && pix[i+1]>80 && pix[i+2]>65 && pix[i+1] > pix[i+2]*0.7)coloured++;
        if(pix[i+1]>pix[i] && pix[i+1]>pix[i+2])green++;
       }
       return {w,h,expectedW:Math.round(rect.width*devicePixelRatio),expectedH:Math.round(rect.height*devicePixelRatio),coloured,solid,green};}''')
    before=canvas_state()
    assert before['w']==before['expectedW'] and before['h']==before['expectedH'],('initial wrong buffer',width,before)
    # Test actual movement rather than just a static empty canvas.
    page.locator('[data-action="sim3-play"]:visible').first.click()
    page.wait_for_timeout(600)
    after=canvas_state()
    assert after['w']==after['expectedW'] and after['h']==after['expectedH'],('lost canvas buffer when playing',width,after)
    assert after['coloured']>150,('horse silks / scene detail absent',width,after)
    assert page.locator('#s3Status').inner_text()=='SCENARIO IN MOTION'
    for camera in CAMERAS:
      page.locator(f'[data-action="sim3-camera:{camera}"]:visible').first.click()
      page.wait_for_timeout(90)
      check=canvas_state()
      assert check['w']==check['expectedW'] and check['h']==check['expectedH'],('camera buffer',width,camera,check)
      assert check['solid']>check['w']*check['h']*.5,('blank view',width,camera,check)
    # Switch to broadcast, pause and replay. Changing the DOM on play must not blank drawing again.
    page.locator('[data-action="sim3-camera:broadcast"]:visible').first.click()
    page.locator('[data-action="sim3-play"]:visible').first.click()
    page.wait_for_timeout(100)
    assert page.locator('#s3Status').inner_text()=='PAUSED / READY'
    page.locator('[data-action="sim3-replay"]:visible').first.click()
    page.wait_for_timeout(100)
    replay=canvas_state()
    assert replay['w']==replay['expectedW'] and replay['h']==replay['expectedH']
    assert replay['coloured']>150
    # browser viewport resize while race runs must maintain proper drawing buffer
    page.set_viewport_size({'width':max(365,width-30),'height':height})
    page.wait_for_timeout(140)
    resize=canvas_state()
    assert resize['w']==resize['expectedW'] and resize['h']==resize['expectedH']
    assert resize['solid']>resize['w']*resize['h']*.5
    assert not errors, ('browser JS errors',errors)
    print(f'{width}px viewport PASS: horses visible, 4 views, pause/replay, resize | canvas {resize["w"]} x {resize["h"]}')
    page.close()
  browser.close()
