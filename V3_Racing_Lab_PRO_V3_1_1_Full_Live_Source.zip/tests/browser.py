import json,threading,http.server,functools
from playwright.sync_api import sync_playwright
root='/mnt/data/v3_live_build'; html=open(root+'/index.html').read();url='https://racing-lab.test/'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for name,w in [('desktop',1365),('iphone',390)]:
  page=b.new_page(viewport={'width':w,'height':844});errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  
  #page.route('**/api/v1/snapshot',lambda rt:rt.fulfill(status=503,content_type='application/json',body='{"message":"Set AIRTABLE_PAT in Netlify"}'))
  #page.route('**/api/v1/calibration',lambda rt:rt.fulfill(status=200,content_type='application/json',body=json.dumps({'status':'NO_VERIFIED_BACKTEST','eligibleRaces':0,'eligibleRunners':0,'totalResultRecords':0,'unverifiedRecords':0,'rejectedRaceVersions':0,'raceBrier':None,'raceLogLoss':None,'warning':'No verified history', 'bands':[]})))
  page.set_content(html,wait_until='domcontentloaded');page.wait_for_timeout(350)
  assert 'V3.1' in page.title(),page.title()
  assert page.locator('#screen').count()==1
  for section in ['races','daily','multi','simulator','compare','weather','quality','settings','calibration']:
   if name=='iphone' and section in ('quality','settings','calibration'):
    page.evaluate("x=>document.querySelector(`[data-page='${x}']`).click()",section)
   else:page.locator(f'[data-page="{section}"]:visible').first.click()
   assert len(page.locator('#screen').inner_text())>150,(name,section)
  assert 'Calibration not established' in page.locator('#screen').inner_text()
  assert 'Airtable live feed not connected' in page.locator('#screen').inner_text()
  page.locator('[data-page="simulator"]:visible').first.click()
  assert page.locator('#s3Canvas').count()==1
  page.locator('[data-change="sim-race"]').select_option('RANDWICK_R05')
  page.locator('[data-action="sim3-play"]').click();page.wait_for_timeout(150)
  assert page.locator('#s3Status').count()==1
  assert not errs,(name,errs)
  page.screenshot(path=f'/mnt/data/v3_live_build/tests/{name}_qa.png',full_page=False)
  print(name,{'errors':errs,'width':page.evaluate('document.documentElement.scrollWidth'),'view':w})
  page.close()
 b.close()

